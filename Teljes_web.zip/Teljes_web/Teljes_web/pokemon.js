const gomb = document.getElementById("gomb");

gomb.addEventListener("click", async () => {
    const nev = document.getElementById("pokemonNeve").value.toLowerCase();

    try {
        const res = await fetch(`https://pokeapi.co/api/v2/pokemon/${nev}`);

        if (!res.ok) {
            alert("Nincs ilyen Pokémon!");
            return;
        }
        const data = await res.json();

        document.getElementById("kep").src = data.sprites.front_default;
        document.getElementById("name").innerText ="Név: " + data.name.toUpperCase();

        const abilities = data.abilities
            .map(a => a.ability.name)
            .join(", ");

        document.getElementById("abilities").innerText =
            "Képességek: " + abilities;
        const kg = data.weight / 10;
        document.getElementById("weight").innerText =
            "Súly: " + kg + " kg";

        document.getElementById("card").style.display = "block";

    } catch (err) {
        console.error(err);
        alert("Hiba történt a lekérésnél!");
    }
});
