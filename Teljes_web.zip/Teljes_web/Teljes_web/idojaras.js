const gomb = document.getElementById("gomb")
async function idolekerdezes(gomb) {
    const varos = document.getElementById("varoslekerdezes").value.toLowerCase()
    fetch(`https://api.worldweatheronline.com/premium/v1/weather.ashx?key=b79f837224f9473ea9a123308260304&q=${varos}&format=json`)
    .then(adat => {
        if(!adat.ok){
            console.log("Rosz adatbevitel")
       }
        else{
            //console.log(adat.json())
            return adat.json()
        }
    })
    .then(homer => {
        const now = new Date();
        const time = now.toLocaleTimeString();
        const sor = Math.floor((time[0] + time[1]) / 3);


        const homerseklet = homer.data.weather[0].hourly[sor].tempC;
        const szelsebesseg = homer.data.weather[0].hourly[sor].windspeedKmph;
        const paratartalom = homer.data.weather[0].hourly[sor].humidity;
        const felhozet = homer.data.weather[0].hourly[sor].cloudcover;
        const hoerzet = homer.data.weather[0].hourly[sor].FeelsLikeC
        document.getElementById("Idojaras").innerText = homerseklet + "°";
        document.getElementById("szelsebesseg").innerHTML = szelsebesseg + "Km/h";
        document.getElementById("paratartalom").innerHTML = paratartalom + "%";
        document.getElementById("felho").innerHTML = felhozet + "%";
        document.getElementById("erzet").innerHTML = hoerzet + "°";
        //a kovetkezo napok idojarasa
        document.getElementById("max1").innerHTML = homer.data.weather[1].maxtempC+"°";
        document.getElementById("max2").innerHTML = homer.data.weather[2].maxtempC +"°";
        document.getElementById("min1").innerHTML = homer.data.weather[1].mintempC +"°";
        document.getElementById("min2").innerHTML = homer.data.weather[2].mintempC + "°";
        }
    )
    .catch(err => console.log(err));
}
gomb.addEventListener('click', idolekerdezes);
