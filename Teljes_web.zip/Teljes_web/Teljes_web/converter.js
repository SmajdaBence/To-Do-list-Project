const textBox = document.querySelector("#textBox")
const toFarenheit = document.querySelector("#toFarenheit")
const toCelsius = document.querySelector("#toCelsius")
const display = document.querySelector("#display")
let temp;

function convert(){
    if (toFarenheit.checked){
        temp = Number(textBox.value)
        temp = temp*9/5 + 32
        display.value = temp.toFixed(1) + "°F"
    }
    else if(toCelsius.checked){
        temp = Number(textBox.value)
        temp = (temp-32) * (5/9)
        display.value = temp.toFixed(1) + "°C"
    }
    else{
        display.value = "Select a unit "
    }
}
