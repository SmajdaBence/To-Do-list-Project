const gomb = document.getElementById("gomb");

async function idolekerdezes() {
    const varos = document.getElementById("varoslekerdezes").value.toLowerCase();

    try {
        const adat = await fetch(`https://api.worldweatheronline.com/premium/v1/weather.ashx?key=b79f837224f9473ea9a123308260304&q=${varos}&format=json`);

        if (!adat.ok) {
            console.log("Rossz adatbevitel");
            return;
        }

        const homer = await adat.json();

        const now = new Date();
        const hour = now.getHours();
        const sor = Math.min(Math.floor(hour / 3), 7);
        const homerseklet = homer.data.weather[0].hourly[sor].tempC;
        const szelsebesseg = homer.data.weather[0].hourly[sor].windspeedKmph;
        const paratartalom = homer.data.weather[0].hourly[sor].humidity;
        const felhozet = homer.data.weather[0].hourly[sor].cloudcover;
        const hoerzet = homer.data.weather[0].hourly[sor].FeelsLikeC;

        document.getElementById("Idojaras").innerText = homerseklet + "°";
        document.getElementById("szelsebesseg").innerHTML = szelsebesseg + " Km/h";
        document.getElementById("paratartalom").innerHTML = paratartalom + "%";
        document.getElementById("felho").innerHTML = felhozet + "%";
        document.getElementById("erzet").innerHTML = hoerzet + "°";

        document.getElementById("max1").innerHTML = homer.data.weather[1].maxtempC + "°";
        document.getElementById("max2").innerHTML = homer.data.weather[2].maxtempC + "°";
        document.getElementById("min1").innerHTML = homer.data.weather[1].mintempC + "°";
        document.getElementById("min2").innerHTML = homer.data.weather[2].mintempC + "°";

    } catch (err) {
        console.log(err);
    }
}
gomb.addEventListener('click', idolekerdezes);